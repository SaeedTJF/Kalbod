import style from './AdminHeader.module.css'
export default function AdminHeader () {
    return (
        <div className={style.header}>

        </div>
    )
}