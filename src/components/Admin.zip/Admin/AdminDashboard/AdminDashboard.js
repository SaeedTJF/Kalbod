import style from './AdminDashboard.module.css'
export default function AdminDashboard () {
    return (
        <div className={style.dashboard}>

        </div>
    )
}